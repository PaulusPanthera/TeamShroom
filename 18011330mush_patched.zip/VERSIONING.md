# Versioning

- main = current active website (v2 rewrite)
- v1-backup = legacy website (pre-rewrite)
- alpha = rebuilding, incomplete, unstable
- beta = feature-complete, polishing & testing
- tags mark important milestones and are never moved
