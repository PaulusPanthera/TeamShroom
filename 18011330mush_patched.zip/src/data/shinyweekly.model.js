// src/data/shinyweekly.model.js
// v2.0.0-beta
// Re-export ShinyWeekly model normalization from domains

export { buildShinyWeeklyModel } from '../domains/shinyweekly/shinyweekly.model.js';
